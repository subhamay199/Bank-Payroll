package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServiceImpl;
import com.cg.banking.services.BankingServices;

public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException {
		//AccountDAOImpl service = new AccountDAOImpl();
		Transaction transaction = new Transaction();
		BankingServices services=new BankingServiceImpl();
		Scanner sc=new Scanner(System.in);
		int userChoice;
		do {
			System.out.println("_____________________________Welcome to My Bank______________________________");
			System.out.println("Please enter any one of the given choices :");
			System.out.println("Press 1 Create a account");
			System.out.println("Press 2 Get your account details");
			System.out.println("Press 3 Get all account details\n\n\n");
			System.out.println("Press 4 for Exit");
			userChoice=sc.nextInt();
			switch(userChoice) {
			case 1: System.out.println("Enter the type of account you want to open:");
			System.out.println("Note: Savings or Current");
			String accountType=sc.next();
			System.out.println("Enter your current Balance");
			float initialBalance=sc.nextFloat();
			Account account = services.openAccount(accountType,initialBalance);
			System.out.println("******ACCOUNT CREATED******");
			System.out.println(account);
			break;
			case 2:System.out.println("Enter the account number");
			long accountNumber=sc.nextLong();
			try {
				System.out.println(services.getAccountDetails(accountNumber));
			} catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
			case 3 : System.out.println(services.getAllAccountDetails());
			break;
			case 4:System.exit(0);
			default: System.out.println("Oops!!!Wrong Choice");break;			
			}}while(userChoice!=4);
	}
}
