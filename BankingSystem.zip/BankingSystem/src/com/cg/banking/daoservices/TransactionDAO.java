package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;

public interface TransactionDAO {
	Transaction save(int accountNo,Transaction transaction);
	//boolean update(Transaction transaction);
	Transaction findOne(int accountNo,int transactionId);
	List<Transaction> findAll(int accountNo);
}
