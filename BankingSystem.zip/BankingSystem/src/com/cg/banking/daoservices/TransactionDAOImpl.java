package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO {

	@Override
	public Transaction save(int accountNo,Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getAccount_ID_COUNTER());
		BankingDBUtil.accounts.get(accountNo).getTransactions().put((int)transaction.getTransactionId(),transaction);
		return transaction;
	}


	@Override
	public Transaction findOne(int accountNo,int transactionId) {
		// TODO Auto-generated method stub
		return BankingDBUtil.accounts.get(accountNo).getTransactions().get(transactionId);
	}

	@Override
	public List<Transaction> findAll(int accountNo) {
			return new ArrayList<Transaction>(BankingDBUtil.accounts.get(accountNo).getTransactions().values());
	
	}
}
