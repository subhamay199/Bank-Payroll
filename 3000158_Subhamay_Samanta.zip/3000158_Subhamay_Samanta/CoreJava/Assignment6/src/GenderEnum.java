
public enum GenderEnum {
	M,F;
}
