
public class BlankNameException extends Exception
{
	public BlankNameException()
	{
		System.out.println("Name Is Null");
	}
}
