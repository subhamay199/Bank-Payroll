package com.cg.project.collections;
public class MainClass {

	public static void main(String[] args) {
		
		ListClassesDemo.arrayListClassDemo();
		
		ListClassesDemo.linkedListClassDemo();

	}

}
