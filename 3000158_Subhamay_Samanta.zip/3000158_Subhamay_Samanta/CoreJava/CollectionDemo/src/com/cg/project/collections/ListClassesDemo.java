package com.cg.project.collections;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class ListClassesDemo {
	public static void arrayListClassDemo() {
		
		ArrayList<String > strList=new ArrayList<>();
		strList.add("Satish");
		strList.add("Kumar");
		strList.add("Nilesh");
		strList.add("Rakesh");
		strList.add("Ayush");
		strList.add("Mayur");
		
		System.out.println(strList);
		String nameToBeSearch="Ayush";
		System.out.println(strList.contains(nameToBeSearch));
		
		String nameToRemove="Kumar";
		System.out.println(strList.remove(nameToRemove));
		
		ArrayList<Associate > associates=new ArrayList<>();
		
		associates.add(new Associate(111,"Satish","mahajan",20000));
		
		Associate associateToBeSearch=new Associate(114,"Mayur","patil",13499);
		System.out.println(associates.contains(associateToBeSearch));
		
		Collections.sort(associates);
		 
		for (Associate associate : associates) {
			System.out.println(associate);
			
		}
		
		System.out.println("--------------------------------------------");
		
		//Collections.sort(associates,new AssociateComparator());

		
		for (Associate associate : associates) {
			System.out.println(associate);
			
		}
		
		System.out.println("--------------------------------------------");

	}

public static void linkedListClassDemo() {
		
		LinkedList<String > strList=new LinkedList<>();
		strList.add("Satish");
		strList.add("Kumar");
		strList.add("Nilesh");
		strList.add("Rakesh");
		strList.add("Ayush");
		strList.add("Mayur");
		
		System.out.println(strList);
		String nameToBeSearch="Ayush";
		System.out.println(strList.contains(nameToBeSearch));
		
		String nameToRemove="Kumar";
		System.out.println(strList.remove(nameToRemove));
		
		LinkedList<Associate > associates=new LinkedList<>();
		
		associates.add(new Associate(111,"Satish","mahajan",20000));
		
		Associate associateToBeSearch=new Associate(114,"Mayur","patil",13499);
		System.out.println(associates.contains(associateToBeSearch));
		
		Collections.sort(associates);
		 
		for (Associate associate : associates) {
			System.out.println(associate);
			
		}
		
		System.out.println("--------------------------------------------");
		
		Collections.sort(associates,new AssociateComparator());

		
		for (Associate associate : associates) {
			System.out.println(associate);
			
		}
		
		System.out.println("--------------------------------------------");

	}
	
}
