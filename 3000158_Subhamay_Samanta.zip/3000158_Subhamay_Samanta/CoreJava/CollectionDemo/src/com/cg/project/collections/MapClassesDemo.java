package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

public class MapClassesDemo {
	Hashtable<Integer,Associate> associates=new Hashtable<>();	
	associates.put(111,new Associate(111,"Satish","Mahajan",15000));
	associates.put(112,new Associate(114,"Kumar","Raj",44222));
	associates.put(114,new Associate(111,"Ayush","Patil",17980));
	
	associates.put(112,new Associate(111,"Mayur","Patil",13299));
	associates.put(115,new Associate(111,"Nilesh","Kumar",84259));
	
	Associate associate=associates.get(112);
	associates.remove(112);
	
	Set<Integer> keys=associates.keySet();
	
	
	ArrayList<Associate > associateList=new ArrayList<>(associates.values());
}
