package com.cg.project.readwritework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.cg.project.beans.Address;
import com.cg.project.beans.Customer;

public class SerializableDemo implements Serializable{
	public static void doSerialiazation(File file) throws FileNotFoundException,IOException {
		try(ObjectOutputStream writer=new ObjectOutputStream(new FileOutputStream(file))) {
			Customer customer=new Customer(111,"Satish","Mahajan",new Address("pune","India"));
			writer.writeObject(customer);
			System.out.println("Customer Object Transfered To"+file.getAbsolutePath());
			
		}
	}
	public static void doDeSerialiazation(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream reader=new ObjectInputStream(new FileInputStream(file))) {
			Customer customer=(Customer) reader.readObject();
				System.out.println(customer);
			
		}
	}
}

