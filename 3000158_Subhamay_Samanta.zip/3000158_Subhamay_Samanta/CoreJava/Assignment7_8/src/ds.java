
public class ds implements Runnable
	{
	   public void run()
	   {
	      for ( int i=1; i<=10; i++)
	      {
	         System.out.println( "Message from Thread : " +i);
	 
	         try
	         {
	             Thread.sleep(10);
	         }
	         catch (InterruptedException interruptedException)
	         {
	          
	             System.out.println( "Second Thread is interrupted when it is sleeping" +interruptedException);
	         }
	      }
	   }
	}