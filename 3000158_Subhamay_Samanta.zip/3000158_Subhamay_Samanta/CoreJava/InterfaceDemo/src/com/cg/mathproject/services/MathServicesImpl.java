package com.cg.mathproject.services;

import com.cg.mathproject.exception.NegativeNumberException;

public class MathServicesImpl implements MathServices {

	@Override
	public int add(int n1, int n2) throws NegativeNumberException {
		if(n1<0||n2<0)
			throw new NegativeNumberException();
		return n1+n2;
	}

	@Override
	public int sub(int n1, int n2) throws NegativeNumberException {
		if(n1<0||n2<0)
			throw new NegativeNumberException();
		return n1-n2;
	}

	@Override
	public int div(int n1, int n2) throws NegativeNumberException {
		if(n1<0||n2<0)
			throw new NegativeNumberException();
		return n1/n2;
	}

	@Override
	public int multi(int n1, int n2) throws NegativeNumberException {
		if(n1<0||n2<0)
			throw new NegativeNumberException();
		return n1*n2;
	}
	
}
