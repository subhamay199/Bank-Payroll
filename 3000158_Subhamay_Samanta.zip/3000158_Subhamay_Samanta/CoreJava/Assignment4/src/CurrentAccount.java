public class CurrentAccount extends Account
{
	private double overDraftLimit;
	public CurrentAccount(long accNum,double balance,double amount,double overdraft)
	{
		this.accNum=accNum;
		this.balance=balance;
		this.overDraftLimit=overDraftLimit;
	}
	public void withdraw(double amount) throws OverDraftLimitException
	{
		if(amount<=overDraftLimit)
		{
			balance-=amount;
			}
		else
			throw new OverDraftLimitException();
		
	}
}
