package com.cg.bean;

public class MainClass {

	public static void main(String[] args) {
		Employee emp1=new Employee(111,"Subhamay","Samanta",15200);
		Employee emp2=new Employee(111,"Subhamay","Samanta",15200);
		Object obj=emp2;
		
		if(emp1.equals(emp2))
		{
			System.out.println("Equal");
		}
		else
			System.out.println("Not Equal");

		if(obj.equals(emp2)) {
			System.out.println("Equal");
		}
		else
			System.out.println("Not Equal");

}
}
