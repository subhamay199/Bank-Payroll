package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDAO;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	@Before
	public  void setUpTestMockdata() {
		Associate associate1=new Associate(101, 78000,"Satish","Mahajan","Training","Manager","DTDYF122","satish.mahajan@capgemini.com",new BankDetails(12345,"HDFC","fdg"),new Salary(35000,1800,1800));
		Associate associate2=new Associate(102, 48000,"mk","M","Training","Manager","DLTDYF122","satish@capgemini.com",new BankDetails(125,"HDFC","fdg"),new Salary(30500,2800,1000));
		Associate associate3=new Associate(65540, 78000,"mayur","patil","adc","C","DTDYF122","mahajan@capgemini.com",new BankDetails(12345,"AXIS","fdgw"),new Salary(32000,1500,1200));
		
		ArrayList<Associate> associatesList=new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(associate3);
		EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
		EasyMock.replay(mockAssociateDAO);
		//payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailNotFoundException
	{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDAO.findOne(101));
	}
	@Test
	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailNotFoundException
	{
		Associate expectedAssociate=new Associate(101, 78000,"Satish","Mahajan","Training","Manager","DTDYF122","satish.mahajan@capgemini.com",new BankDetails(12345,"HDFC","fdg"),new Salary(35000,1800,1800));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		assertEquals(expectedAssociate,actualAssociate);
		EasyMock.verify(mockAssociateDAO.findOne(101));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDAO);
	}
	@AfterClass
	public void tearDownTestEnv() {
		mockAssociateDAO=null;
		payrollServices=null;
	}
}
