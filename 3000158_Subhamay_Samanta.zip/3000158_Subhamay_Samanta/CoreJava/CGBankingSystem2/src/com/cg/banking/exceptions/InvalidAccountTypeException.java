package com.cg.banking.exceptions;

public class InvalidAccountTypeException extends Exception{

}
