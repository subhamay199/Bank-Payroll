package com.cg.banking.client;

import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		BankingServices services=new BankingServicesImpl();
		services.openAccount("Activated", 500);
		

	}

}
