package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
	public static HashMap<Integer,Account> accounts=new HashMap<>();
	private static int Account_ID_COUNTER=100;
	public static String accountStatus = "Active";
	public static int getAccount_ID_COUNTER() {
		return ++Account_ID_COUNTER;
}
	private static int pinNumber=(int) (Math.random()*1000);
	public static int getPIN_NUMBER() {
		return ++pinNumber;
	}
	public static String getACCOUNT_STATUS() {
	//	String accountStatus;
		return accountStatus;
	}
}
