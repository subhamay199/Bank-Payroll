import java.util.Arrays;
import java.util.Scanner;
public class Assignment3_8 
{
	public static String[] sort(String[] array,int n)
	{
		for(int i=0;i<n;i++)
		{
			char tempArray[]=array[i].toCharArray();
			Arrays.sort(tempArray);
			array[i]=new String(tempArray);
		}
		return array;
	}
	public static void upperCase(String[] array,int n)
	{
		array=sort(array,n);
		if(n%2==0)
		{
			for(int i=0;i<n/2;i++)
			{
				array[i]=array[i].toUpperCase();
			}
		}
		else
		{
		for(int i=0;i<(n/2+1);i++)
		{	
			array[i]=array[i].toUpperCase();
		}
		}
		for(int i=0;i<n;i++)
		{	
			System.out.println(array[i]);
		}
	}
	public static void main(String[] args) 
	{
		String[] array=new String[20];
		System.out.println("Please Enter No. Of Names");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Please Enter Names:");
		for(int i=0;i<n;i++)
		{ 	
			array[i]=sc.next();
		}
		upperCase(array,n);
		}
}


